<?php
// include do footer
include_once './includes/_banco.php';
include_once './includes/_footer.php';
include_once './includes/_head.php';
include_once './includes/_header.php';
?>
<h1>Consulta</h1>